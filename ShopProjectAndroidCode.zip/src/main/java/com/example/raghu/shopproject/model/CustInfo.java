package com.example.raghu.shopproject.model;

/**
 * Created by Raghu on 17-Nov-17.
 */

public class CustInfo {

    String cust_name;

    public String getCust_name() {
        return cust_name;
    }

    public void setCust_name(String cust_name) {
        this.cust_name = cust_name;
    }
    //    String custAddress;String custPhone;String custGstin;String custStateCode;



//    public String getCustAddress() {
//        return custAddress;
//    }
//
//    public void setCustAddress(String custAddress) {
//        this.custAddress = custAddress;
//    }
//
//    public String getCustPhone() {
//        return custPhone;
//    }
//
//    public void setCustPhone(String custPhone) {
//        this.custPhone = custPhone;
//    }
//
//    public String getCustGstin() {
//        return custGstin;
//    }
//
//    public void setCustGstin(String custGstin) {
//        this.custGstin = custGstin;
//    }
//
//    public String getCustStateCode() {
//        return custStateCode;
//    }
//
//    public void setCustStateCode(String custStateCode) {
//        this.custStateCode = custStateCode;
//    }


}
