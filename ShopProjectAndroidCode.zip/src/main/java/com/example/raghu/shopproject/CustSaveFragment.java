package com.example.raghu.shopproject;

import com.example.raghu.shopproject.model.*;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 */
public class CustSaveFragment extends Fragment
        implements View.OnFocusChangeListener,AdapterView.OnItemClickListener

{
    private EditText caddress, cgstin, cphone, cdate, ccurbal, cemail;
    private TextInputLayout cgstInputLay;
    private Spinner spinnercusttype,spinnercuststate;
    private Switch cswitch;
    private TextView cnamelist;private String value="Receivable";
    static final int REQUEST_CONTACT_READ = 1;
    Animation Slideup, Slidedown;
//    private static boolean gstVisible=false;


    HashMap<String,String> nameContact;

    FragmentTransaction fragmentTransaction;
    private ArrayList<String> custdetaillist=new ArrayList<String>();
//private ArrayList<String> custdetaillist=new ArrayList<>();
    private Button savebtn;
    private ListView listView;
AutoCompleteTextView cname;
    Calendar calendar;

    public CustSaveFragment() {

        calendar=Calendar.getInstance();

        selectData();


//        cdate.setText(date.toString());
       // updateLabel();
    }

//    @Override
//    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
//        calendar.set(Calendar.YEAR, year);
//        calendar.set(Calendar.MONTH, month);
//        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//        updateLabel();
//    }
    private void updateLabel() {
        String myFormat = "dd/MM/yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
        cdate.setText(sdf.format(calendar.getTime()));
//        cdate.setText(sdf.format(new Date()));
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view= inflater.inflate(R.layout.fragment_cust_save, container, false);

        spinnercuststate=(Spinner)view.findViewById(R.id.spin_cust_state);
        String[] countries=getResources().getStringArray(R.array.statecode);
        ArrayAdapter<String> spincuststate = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, countries);
//        ArrayAdapter<CharSequence> spinnerArray=ArrayAdapter.createFromResource(getContext(),
//                R.array.custtype,android.R.layout.simple_spinner_item);
        spincuststate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercuststate.setAdapter(spincuststate);
        spinnercusttype=(Spinner)view.findViewById(R.id.spin_cust_type);
        String[] customerType=getResources().getStringArray(R.array.custtype);
        ArrayAdapter<String> spinnerArray = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, customerType);
//        ArrayAdapter<CharSequence> spinnerArray=ArrayAdapter.createFromResource(getContext(),
//                R.array.custtype,android.R.layout.simple_spinner_item);
        spinnerArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercusttype.setAdapter(spinnerArray);

        cname=(AutoCompleteTextView)view.findViewById(R.id.cust_name);

        cdate=(EditText)view.findViewById(R.id.cust_date);
        cgstInputLay=(TextInputLayout) view.findViewById(R.id.text_cgstin_layout);
       // cname=(EditText)view.findViewById(R.id.cust_name);
        caddress=(EditText)view.findViewById(R.id.cust_address);
        cphone=(EditText)view.findViewById(R.id.cust_phone);
        cgstin=(EditText)view.findViewById(R.id.cust_gstin);
//        cstate_code=(EditText)view.findViewById(R.id.cust_state);
        cnamelist=(TextView)view.findViewById(R.id.cust_name_list);
        ccurbal=(EditText)view.findViewById(R.id.cust_cur_bal);
        cemail=(EditText)view.findViewById(R.id.cust_email);
        cswitch=(Switch)view.findViewById(R.id.cust_switch);


        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy",Locale.US);
        String date=simpleDateFormat.format(new Date());
        cdate.setText(date);


        listView=(ListView)view.findViewById(R.id.cust_list);
        savebtn=(Button)view.findViewById(R.id.cust_save_btn);
        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCustInfo();
            }
        });
        cdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatePickerDialog.OnDateSetListener dpd = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear,
                                          int dayOfMonth) {

                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, monthOfYear);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        updateLabel();
                    }
                };


                DatePickerDialog d = new DatePickerDialog(getContext(),dpd,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH)
                ,calendar.get(Calendar.DAY_OF_MONTH));
                d.show();
            }
        });


        Slidedown = AnimationUtils.loadAnimation(getContext(), R.anim.slide_down);
        Slideup = AnimationUtils.loadAnimation(getContext(),R.anim.slide_up);
//        gstVisible(false);
        cname.setOnFocusChangeListener(this);
        cname.setOnItemClickListener(this);
        spinnercusttype.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String custType=parent.getItemAtPosition(position).toString();
                Log.e("Cust Type ",custType);
                if(custType.equalsIgnoreCase("Unregistered Customer")){
                    Log.e("Inside Cust Type ",custType);


                    cgstInputLay.setVisibility(View.GONE);
                    cgstin.setVisibility(View.GONE);

                }
                else{


                    cgstInputLay.setVisibility(View.VISIBLE);
                    cgstin.setVisibility(View.VISIBLE);

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
//                   gstVisible(false);
            }
        });
//        cname.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View v, boolean hasFocus) {
//                Log.e("Has Permission",String.valueOf(hasPermission()));
//                if(hasPermission()){
//                    showContactFunctionality();
//                }
//                else{
//                    requestPermission();
//                }
//            }
//        });
        cswitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {


                if(isChecked){
                    value=cswitch.getTextOn().toString();
                }
                else{
                    value=cswitch.getTextOff().toString();
                }
                Log.e("Switch Boolean",String.valueOf(isChecked)+" Value "+value);
            }

        });

//        ccurbal.setOnKeyListener(new View.OnKeyListener() {
//            @Override
//            public boolean onKey(View v, int keyCode, KeyEvent event) {
//                Log.e("Switch Boolean",event.getCharacters());
//                    cswitch.setVisibility(View.VISIBLE);
//
//                    return true;
//
//            }
//        });


        return  view;

    }

    private void gstVisible(boolean gstVisible){
        if(gstVisible){
//            cgstin.startAnimation(Slidedown);
//            cgstInputLay.startAnimation(Slidedown);
           // gstVisible=false;
        }
        else{
//            cgstin.startAnimation(Slideup);
//            cgstInputLay.startAnimation(Slideup);
           // gstVisible=true;
        }
    }


    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        checkContactPermission();
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String value=parent.getItemAtPosition(position).toString();
        cphone.setText(nameContact.get(value));
        Log.e("On ItemClick Name",value);
        Log.e("On ItemClick Number",nameContact.get(value));
    }

    private void showOkCancelMsg(String msg, DialogInterface.OnClickListener okListener){

    new AlertDialog.Builder(getContext()).setMessage(msg).setPositiveButton("OK",okListener)
            .setNegativeButton("Cancel",null)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setTitle("Permission Alert!!")
            .create()
            .show();


    }

private void checkContactPermission(){

    Log.e("Permession Contact ",String.valueOf(hasPermission()));
    if(hasPermission()){
        showContactFunctionality();
        Toast.makeText(getContext(),"Contact Write Permission Granted",Toast.LENGTH_LONG).show();
    }
    else{
        if(!shouldShowRequestPermissionRationale(Manifest.permission.READ_CONTACTS)){

            showOkCancelMsg("You need to allow access to the contact", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    requestPermission();
                }
            });
            return;
        }
        requestPermission();
    }


}

private void getContactToHash(){

    nameContact=new HashMap<>();
    nameContact.clear();
try {
    Cursor phones = getContext().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
    while (phones.moveToNext()) {
        String name = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
        String number = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
        nameContact.put(name, number);
    }
    ArrayList<String> custname=new ArrayList<>();
    for (String key : nameContact.keySet()) {
        custname.add(key);
//            Log.e("Name", key);
//            Log.e("Number", nameContact.get(key));
    }

    ArrayAdapter arrayAdapter=new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,custname);
    cname.setAdapter(arrayAdapter);
    cname.setThreshold(1);

    phones.close();
}
catch (Exception e){
    e.printStackTrace();
}

}


    private boolean hasPermission() {
        int res=0;
        String[] permissions =new String[]{Manifest.permission.READ_CONTACTS};
        for(String params : permissions){
            res= ContextCompat.checkSelfPermission(getContext(),params);
            if(!(res== PackageManager.PERMISSION_GRANTED)){
                return false;
            }
        }

        return true;


    }


    private  void requestPermission(){
        String[] permissions =new String[]{Manifest.permission.READ_CONTACTS};
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
            requestPermissions(permissions,REQUEST_CONTACT_READ);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        boolean allowed = true;
        switch(requestCode){
            case REQUEST_CONTACT_READ:
                for(int res: grantResults){
                    allowed=allowed&&(res==PackageManager.PERMISSION_GRANTED);
                }
                break;
            default:
                allowed=false;
                break;
        }
        if(allowed){
            showContactFunctionality();
        }
        else{
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.READ_CONTACTS)) {
                    Toast.makeText(getContext(), "Contact Permission is needed to access contact", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
    public void showContactFunctionality(){
//        Toast.makeText(getContext(), "Contact Permission Granted", Toast.LENGTH_LONG).show();
//
//        Intent pickContact=new Intent(Intent.ACTION_PICK, Uri.parse("content://contacts"));
//        pickContact.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
//        startActivityForResult(pickContact,1);
        getContactToHash();
    }

    public void saveCustInfo() {
        String custName = cname.getText().toString();
        String custAdd = caddress.getText().toString();
        String custBal = ccurbal.getText().toString();
        String custtype = spinnercusttype.getSelectedItem().toString();
        String custState = spinnercuststate.getSelectedItem().toString();
        String custGstin = "No gst detail";
        String custPhone = cphone.getText().toString();
        String custDate=cdate.getText().toString();
        String custEmail="No Email Detail";
        if(!custtype.equalsIgnoreCase("Unregistered Customer")){
            if (!cgstin.getText().toString().equalsIgnoreCase("")&&
                    !cgstin.getText().toString().equalsIgnoreCase(null)) {
                custGstin=cgstin.getText().toString();
                Toast.makeText(getContext(),"CGST ="+custGstin,Toast.LENGTH_SHORT).show();
            }
            else{
                cgstin.requestFocus();
                cgstin.setError("CGST Detail Required");
            }
        }
        if (custName.equalsIgnoreCase("")) {
            cname.requestFocus();
            cname.setError("Name Required");
        }

        else if(custState.equalsIgnoreCase("Select State")){
             spinnercuststate.requestFocus();
             Toast.makeText(getContext(),"Please Select State",Toast.LENGTH_SHORT).show();
        }else if (custAdd.equalsIgnoreCase("")) {
            caddress.requestFocus();
            caddress.setError("Address Required");
        }
        else if (custBal.equalsIgnoreCase("")) {
            ccurbal.requestFocus();
            ccurbal.setError("Initial Balance Required");
        }
      else if (custDate.equalsIgnoreCase("")) {
            Toast.makeText(getContext(),"Date Required",Toast.LENGTH_SHORT);
        }
        else if (!cemail.getText().toString().equalsIgnoreCase("")&&
                !cemail.getText().toString().equalsIgnoreCase(null)) {
            custEmail=cemail.getText().toString();
//            Toast.makeText(getContext(),"Date Required",Toast.LENGTH_SHORT);
        }
         else if (custPhone.equalsIgnoreCase("")) {
            cphone.requestFocus();
            cphone.setError("Phone no. Required");
        } else {
            String method = "custsave";
            BackgroundTask backgroundTask =
                    new BackgroundTask(getContext());
            Toast.makeText(getContext(),"AsynTask Inside=",Toast.LENGTH_SHORT).show();
            backgroundTask.execute(method, custName, custAdd, custPhone,
                    custGstin, custState,
                    spinnercusttype.getSelectedItem().toString(),custEmail,
                    custBal,custDate,value );
        }

    }

    private void selectData(){
        String method="selectcustdata";
        BackgroundTask backgroundTask =
                new BackgroundTask(getContext());
        backgroundTask.execute(method);

    }


    class BackgroundTask extends AsyncTask<String, Void, String> {

        Context ctx;

        public BackgroundTask(Context context) {
            ctx = context;
        }

        @Override
        protected void onPreExecute() {


        }

        @Override
        protected String doInBackground(String... params) {

            String method = params[0];
            IPConnection ip = new IPConnection();


            if (method.equalsIgnoreCase("custsave")) {
                HashMap<String, String> nameValuePairs = new HashMap<>();
                nameValuePairs.clear();
                nameValuePairs.put("name", params[1]);
                nameValuePairs.put("address", params[2]);
                nameValuePairs.put("phone", params[3]);
                nameValuePairs.put("gstin", params[4]);
                nameValuePairs.put("statecode", params[5]);
                nameValuePairs.put("custtype", params[6]);
                nameValuePairs.put("email", params[7]);
                nameValuePairs.put("balance", params[8]);
                nameValuePairs.put("date", params[9]);
                nameValuePairs.put("paytype", params[10]);
                String dataseurl = ip.address + ip.custDataSave;
                try {
                    Log.e("DataBase URL", dataseurl);
                    URL url = new URL(dataseurl);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

                    String data = "";
                    for (String key : nameValuePairs.keySet()) {
                        data += URLEncoder.encode(key, "UTF-8") + "=" + URLEncoder.encode(nameValuePairs.get(key), "UTF-8") + "&";
                        Log.e("Data", data);
                    }
                    bufferedWriter.write(data);
                    Log.e("Data", data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                    StringBuilder builder=new StringBuilder();
                    String line="";
                    while ((line = bufferedReader.readLine()) != null) {
                        builder.append(line+"\n");
                    }
                    Log.i("Message Record", builder.toString().trim());
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return builder.toString().trim();
                    //return "Success";
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else if (method.equalsIgnoreCase("selectcustdata")) {
                String dataseurl = ip.address + ip.custAllRecord;
                try {
                    Log.e("DataBase URL", dataseurl);
                    URL url = new URL(dataseurl);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

                    String data = "";
//                    for (String key : nameValuePairs.keySet()) {
//                        data += URLEncoder.encode(key, "UTF-8") + "=" + URLEncoder.encode(nameValuePairs.get(key), "UTF-8") + "&";
//                        Log.e("Data", data);
//                    }
//                    String data =
//                            URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(pass, "UTF-8")+"&"+
//                            URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(pass, "UTF-8")+"&"+
//                            URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(pass, "UTF-8")+"&"+
//                            URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(pass, "UTF-8")+"&"+;
                    bufferedWriter.write(data);
                    Log.e("Data", data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                    StringBuilder builder=new StringBuilder();
                    String line="";
                    while ((line = bufferedReader.readLine()) != null) {
                        builder.append(line+"\n");
                    }
                    Log.e("Message Record", builder.toString().trim());
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return builder.toString().trim();
                    //return "Success";
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        protected void onPostExecute(String result) {
            if(result.equalsIgnoreCase("New record created successfully")){
                selectData();
                Toast.makeText(getActivity(),result,Toast.LENGTH_LONG).show();
                Intent it = new Intent(ctx, custRcrdShowMainActivity.class);
                it.putExtra("username","ABC");
                ctx.startActivity(it);

//                 fragmentTransaction=getFragmentManager().beginTransaction();
//            fragmentTransaction.setCustomAnimations(R.anim.slidein,R.anim.slideout);
//                fragmentTransaction.replace(R.id.fragment_home_layout,new AddTwoLayout());
//            fragmentTransaction.addToBackStack(null);
//            fragmentTransaction.commit();
            }

            else if(result!=null){
               Log.e("Result",result);
                String temp=readJson(result);
                if(temp!=null){
                    Log.e("Temp",temp);

                    Log.e("List Size",String.valueOf(custdetaillist.size()));

         ArrayAdapter<String> listAdapter=new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,custdetaillist);
         listView.setAdapter(listAdapter);
                    setListViewHeight(listView);
//                    for(int j=0;j<listAdapter.getCount();j++){
//                        Log.e("List View",listAdapter.getItem(j).toString());
//                    }

                     for(int i=0;i<custdetaillist.size();i++){
                        Log.e("List Customer Name",custdetaillist.get(i));
                    }
                }
            }



        }

private String readJson(String json_string){
    String name=null;
    Log.e("Jason String",json_string);
    if(json_string!=null){
        try {
            JSONObject jsonObject=new JSONObject(json_string);
            JSONArray jsonArray=jsonObject.getJSONArray("Android");
            int count=0;
            while(count<jsonArray.length()){
                CustInfo custInfo=new CustInfo();
                jsonObject=jsonArray.getJSONObject(count);
                if(jsonObject!=null){
                    name=jsonObject.getString("cust_name");
                    custInfo.setCust_name(jsonObject.getString("cust_name"));
//                    cnamelist.setTag(jsonObject.getString("cust_name"));
//                    cnamelist.setText(jsonObject.getString("cust_name"));
//                    custdetaillist.add(custInfo);
                    custdetaillist.add(custInfo.getCust_name());
                   // Log.d("Customer Name",custInfo.getCust_name());
                    Log.e("Customer Name",jsonObject.getString("cust_name"));
                }
                else{
                    Toast.makeText(getContext()," 2 else NULL Read Json",Toast.LENGTH_SHORT).show();
                }
                count++;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
    else{
        Toast.makeText(getContext(),"1 else Jason String null",Toast.LENGTH_LONG).show();
    }

    return name;
}

public void setListViewHeight(ListView listView){
    ListAdapter listAdapter=listView.getAdapter();
    if(listAdapter==null){
        return;
    }
    int desiredWidth= View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.UNSPECIFIED);
    int totalHeight=0;
    View view=null;
    for(int i=0;i<listAdapter.getCount();i++){
        view=listAdapter.getView(i,view,listView);
        if(i==0){
            view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        view.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
        totalHeight+=view.getMeasuredHeight();
    }
ViewGroup.LayoutParams params=listView.getLayoutParams();
    params.height=totalHeight+(listView.getDividerHeight()*(listAdapter.getCount()-1));
    listView.setLayoutParams(params);
}




    }

}
