package com.example.raghu.shopproject;

import android.net.wifi.WifiManager;
import android.util.Log;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;

/**
 * Created by Raghu on 14-Nov-17.
 */

public class IPConnection {
    InetAddress ip=null;
    String ipAddress="";
    public IPConnection() {
        try {
            ArrayList<InetAddress> arrayList=new ArrayList<InetAddress>();

            try {
                for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                    NetworkInterface intf = en.nextElement();
                    for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                        InetAddress inetAddress = enumIpAddr.nextElement();
                        arrayList.add(inetAddress);
                        inetAddress=null;
                    }
                }
            } catch (SocketException ex) {
                Log.e("SALMAN", ex.toString());
            }

            Log.e("Get Local Host ",arrayList.toString());
//            ip = Inet4Address.getByName("");
//            ipAddress = ip.g;
//            System.out.println("Get Local Host "+ipAddress+" "+ip);
//            Log.e("IP",ip.toString());Log.e("Get Local Host ",ipAddress);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
//    WifiManager wm = (WifiManager)
//    String ip = Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
    String address="http://192.168.42.111/Android/";
//    String imageServerAddress="192.168.42.202/Android/images/";
    String selectcustdata="SelectData.php";
    String uploadimage="uploadImage.php";
    String custDataSave="custDataSave.php";
    String custAllRecord="selectAllCust.php";


}
