package com.example.raghu.shopproject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    EditText uname,upassword;
    String username,password;
    Button login_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uname=(EditText)findViewById(R.id.user);
        upassword=(EditText)findViewById(R.id.pass);
        login_btn=(Button)findViewById(R.id.loginbtn);
    }
    public void Loginbtnclick(View view){
        username=uname.getText().toString();
        password=upassword.getText().toString();
        if(uname.getText().toString().length()==0){
            uname.requestFocus();
            uname.setError("Required");
        }
        else if(upassword.getText().toString().length()==0){
            upassword.requestFocus();
            upassword.setError("Required");
        }
        else{
//                    ConnectivityManager connectivityManager=(ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//                    NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
//                    if(networkInfo!=null&&networkInfo.isConnected()){
            String method="login";
            BackgroundTask backgroundTask=new BackgroundTask(MainActivity.this);
            backgroundTask.execute(method,username,password);
//                    }
//                    else{
//                        displayAlertDialog("Please Check your internet connection! or Registration token not generated.");
//                    }
        }
    }

    class BackgroundTask extends AsyncTask<String,Void,String> {

        String json_String = "";
        JSONObject jsonObject;
        JSONArray jsonArray;
        String temp;
        String user_name;//, user_pass,user_id;
       // String json_url;
       ProgressDialog loading;
        Context ctx;
        public BackgroundTask(Context context){
            ctx=context;
        }

        @Override
        protected void onPreExecute() {

           // json_url="http://192.168.42.235/Android/SelectData.php";

             super.onPreExecute();
            loading=ProgressDialog.show(ctx,"Login..","Please wait...");

        }
        @Override
        protected String doInBackground(String... params) {

            String method=params[0];
            IPConnection ip=new IPConnection();


            if(method.equalsIgnoreCase("login")) {
                String uname = params[1];
                String pass = params[2];
                Log.i("username=",uname);Log.i("password=",pass);
                String dataseurl=ip.address+ip.selectcustdata;
                try {
        Log.e("DataBase URL",dataseurl);
                    URL url = new URL(dataseurl);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    String data = URLEncoder.encode("username", "UTF-8") + "=" + URLEncoder.encode(uname, "UTF-8") + "&" +
                            URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(pass, "UTF-8");
                    bufferedWriter.write(data);
                    Log.e("Data",data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                    StringBuilder builder=new StringBuilder();
                    String line="";
                    while ((line = bufferedReader.readLine()) != null) {
                        builder.append(line+"\n");
                    }
                    Log.i("Message", builder.toString().trim());
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return builder.toString().trim();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return null;
        }

        public String ReadJson(String json_String) {
            String res = null;
            Log.i("Jason String",json_String);
            if(!json_String.equals("")) {
                try {
                    jsonObject = new JSONObject(json_String);
                    JSONObject jsonobj = jsonObject.getJSONObject("Android");
                    int count = 0;
                    // if (!jsonobj.equals(null)) {
//
                    //   jsonObject = jsonobj.getJSONObject(count);
                    if (jsonObject != null) {
                        res = jsonobj.getString("username");
                        //    count++;
                        Log.i("Message Username",res);
                    } else {
                        Log.i("Message","Res ID ERROR");
                    }
                    //   }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else {
                Log.i("Message","Res ID ERROR");
            }
            return res;
        }

        @Override
        protected void onPostExecute(String result) {
            json_String = result;
            try {
                if(json_String!=null && !json_String.equals(""))
                {
                    temp = ReadJson(result);
                    Log.e("On Post Execute=",temp);
                }
            }
            catch (Exception er)
            {}


            if (temp!= null) {
                if (temp.equals("Device Not Registerd OR Not Active")) {

                    Log.i("message","Device Not Registerd OR Not Active");
                }
                else if(temp.equals("Invalid Username Or Password.")) {
                    Log.i("message","Invalid Username Or Password.");

                }
                else /*if (temp.equals("SuccessFull"))*/{

                    LoginDetail();
                    if (!user_name.equals("")&&user_name.equals(user_name)) {

                        Intent it = new Intent(ctx, MenuActivity.class);
                        it.putExtra("username",user_name);
                        ctx.startActivity(it);
                        finish();
                    }

                }

            }
            else{
                displayDialog();
            }
        }

        public void LoginDetail() {
            try {
                jsonObject = new JSONObject(json_String);
                JSONObject jsonobj = jsonObject.getJSONObject("Android");
                // Log.e("AAR", "TAG" + jarray);
//                int count = 0;

                // while (count < jsonArray.length()) {
                //JSONObject object = jsonArray.getJSONObject(count);
                if(jsonobj!=null) {
                    // user_id = object.getString("ID");
                    user_name = jsonobj.getString("username");
                    Log.i("Log In user_name=",user_name);
                    //user_pass = object.getString("password");

                }
                else {
                    Toast.makeText(MainActivity.this, "Connection Fail", Toast.LENGTH_SHORT).show();
                }

                //   count++;
                // }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public void displayDialog(){
            AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Error Message....");
            builder.setMessage("Please Check username and password\n Want to continue");
            builder.setIcon(R.drawable.home_icon);
            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent=new Intent(ctx,MainActivity.class);
                    Log.d("Intent Function","displayDialog Function Yes Click");
                    ctx.startActivity(intent);
                    finish();
                }
            });
            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.show();
        }


    }
}
