package com.example.raghu.shopproject;

/**
 * Created by Raghu on 16-Nov-17.
 */

public class NameValuePair {
    private String Name;
    private String Value;
}
