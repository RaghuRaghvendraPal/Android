package com.example.raghu.shopproject;


import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.util.Base64;
import android.util.Log;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.channels.FileChannel;
import java.sql.DatabaseMetaData;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProductPicDetail extends Fragment {
    FloatingActionButton fab_plus, fab_cam, fab_gal;
    EditText dsn_name,dsn_no,dsn_hsn,dsn_rate,dsn_qty;
    String choosePicMode="";
    Animation FabOpen, FabClose, FabRClockwise, FabRantiClockwise;
    boolean isOpen = false;
   // private Uri photoURI = null;
    //private Uri mHighQualityImageUri=null;
    String mCurrentPhotoPath;
    private Button savebtn;
    File imageName = null;
    //private final int REQUEST_CODE_HIGH_QUALITY_IMAGE=1;

    // private static final int CAMERA_PIC_REQUEST=1888;
    static final int REQUEST_TAKE_PHOTO = 1;
//    static final int REQUEST_CAMERA_PER = 123;
    static final int SELECT_PICTURE = 2;
    ImageView picView;

    public ProductPicDetail() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_product_pic_detail, container, false);
        fab_plus = (FloatingActionButton) view.findViewById(R.id.fab_plus);
        fab_cam = (FloatingActionButton) view.findViewById(R.id.fab_cam);
        fab_gal = (FloatingActionButton) view.findViewById(R.id.fab_gal);
        dsn_name=(EditText)view.findViewById(R.id.dsn_name);
        dsn_no=(EditText)view.findViewById(R.id.dsn_no);
        dsn_hsn=(EditText)view.findViewById(R.id.dsn_hsn);
        dsn_rate=(EditText)view.findViewById(R.id.dsn_rate);
        dsn_qty=(EditText)view.findViewById(R.id.dsn_qty);
        picView = (ImageView) view.findViewById(R.id.img_photo);
        savebtn = (Button) view.findViewById(R.id.dsn_save_btn);
        FabOpen = AnimationUtils.loadAnimation(getContext(), R.anim.fab_open);
        FabClose = AnimationUtils.loadAnimation(getContext(), R.anim.fab_close);
        FabRClockwise = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_clockwise);
        FabRantiClockwise = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_anticlockwise);
        fab_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isOpen) {
                    pluseFebClose();
                } else {
                    fab_cam.startAnimation(FabOpen);
                    fab_gal.startAnimation(FabOpen);
                    fab_plus.startAnimation(FabRClockwise);
                    fab_cam.setClickable(true);
                    fab_gal.setClickable(true);
                    isOpen = true;
                }
            }
        });
        fab_cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("Has Permission",String.valueOf(hasPermission()));
                if(hasPermission()){
                    showCameraFunctionality();
                }
                else{
                    requestPermission();
                }
                pluseFebClose();
            }
        });

        fab_gal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hasPermission()){
                    Intent gallaryIntent = new Intent();
                    gallaryIntent.setType("image/*");
                    gallaryIntent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(gallaryIntent, "Select Picture"), SELECT_PICTURE);

                }
                else{
                    requestPermission();
                }
                pluseFebClose();
            }
        });


        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name=dsn_name.getText().toString();
                String no=dsn_no.getText().toString();
                String hsn=dsn_hsn.getText().toString();
                String rate=dsn_rate.getText().toString();
                String qty=dsn_qty.getText().toString();

                if(name.length()==0){
                    dsn_name.requestFocus();
                    dsn_name.setError("Required");
                }
                else if(no.length()==0){
                    dsn_no.requestFocus();
                    dsn_no.setError("Required");
                }
                else if(hsn.length()==0){
                    dsn_hsn.requestFocus();
                    dsn_hsn.setError("Required");
                }
                else if(rate.length()==0){
                    dsn_rate.requestFocus();
                    dsn_rate.setError("Required");
                }
                else if(qty.length()==0){
                    dsn_qty.requestFocus();
                    dsn_qty.setError("Required");
                }
                else{
//                    ConnectivityManager connectivityManager=(ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//                    NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
//                    if(networkInfo!=null&&networkInfo.isConnected()){
                    String method="saveData";

                    BackgroundTask backgroundTask=new BackgroundTask(getContext());
                   // try {
                  if(choosePicMode.equalsIgnoreCase("fromCamera")){

                 backgroundTask.execute(method,imageName.getName(),
                imageToString(decodeSampledBitmapFromFile(mCurrentPhotoPath,picView.getMaxHeight(),picView.getMaxWidth())),
                name,no,hsn,rate,qty);

                   }
                    else if(choosePicMode.equalsIgnoreCase("fromGallery")) {
                      String timeStamp=new SimpleDateFormat("yyyMMdd_HHmmss").format(new Date());
                      Log.e(" Gallery TimeStamp",timeStamp);
                      String imageFileName="JPEG_"+timeStamp+"_.jpg";
                      Log.e(" Gallery ImageFileName",imageFileName);
                      backgroundTask.execute(method,imageFileName,
                              imageToString(decodeSampledBitmapFromFile(mCurrentPhotoPath,picView.getMaxHeight(),picView.getMaxWidth())),
                              name,no,hsn,rate,qty);

                  }
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }

//                    }
//                    else{
//                        displayAlertDialog("Please Check your internet connection! or Registration token not generated.");
//                    }
                    mCurrentPhotoPath="";
                    choosePicMode="";
                }
            }
        });

        return view;
    }
    private void pluseFebClose(){
        fab_cam.startAnimation(FabClose);
        fab_gal.startAnimation(FabClose);
        fab_plus.startAnimation(FabRantiClockwise);
        fab_cam.setClickable(false);
        fab_gal.setClickable(false);
        isOpen = false;
    }
    private boolean hasPermission() {
      int res=0;
        String[] permissions =new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};
        for(String params : permissions){
            res=ContextCompat.checkSelfPermission(getContext(),params);
            if(!(res==PackageManager.PERMISSION_GRANTED)){
                 return false;
            }
        }

        return true;


    }

   private  void requestPermission(){
       String[] permissions =new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};
       if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
           requestPermissions(permissions,REQUEST_TAKE_PHOTO);
       }
   }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
       boolean allowed = true;
        switch(requestCode){
            case REQUEST_TAKE_PHOTO:
                for(int res: grantResults){
                    allowed=allowed&&(res==PackageManager.PERMISSION_GRANTED);
                }
                break;
            default:
                allowed=false;
                break;
        }
        if(allowed){
            showCameraFunctionality();
        }
        else{
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    Toast.makeText(getContext(), "Camera Permission is needed to show camera preview", Toast.LENGTH_LONG).show();
                }
            }
        }
    }





//
//    public void showCamera(View view){
//        if(ContextCompat.checkSelfPermission(getContext(),Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED){
//            showCameraFunctionality();
//        }
//        else{
//            if(shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)){
//                   Toast.makeText(getContext(),"Camera Permission is needed to show camera preview",Toast.LENGTH_LONG).show();
//            }
//            requestPermissions(new String[]{Manifest.permission.CAMERA},REQUEST_TAKE_PHOTO);
//        }
//    }
///This is from Previous Video
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//       if(requestCode==REQUEST_TAKE_PHOTO){
//             if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
//                 showCameraFunctionality();
//             }
//             else{
//                 Toast.makeText(getContext(),"Permission was not granted",Toast.LENGTH_LONG).show();
//             }
//        }
//        else{
//            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        }
//    }
public void showCameraFunctionality(){

    Intent takePictureIntent=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
    if(takePictureIntent.resolveActivity(getActivity().getPackageManager())!=null){

        try {
            imageName=createImageFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(imageName!=null){
            Uri photoURI= FileProvider.getUriForFile(getContext(),"com.example.android.fileprovider",
                    imageName);
            Log.e("PhotoUri",photoURI.toString());
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,photoURI);
            startActivityForResult(takePictureIntent,REQUEST_TAKE_PHOTO);
    }
    }
}

    private File createImageFile() throws IOException{
        String timeStamp=new SimpleDateFormat("yyyMMdd_HHmmss").format(new Date());
        Log.e("TimeStamp",timeStamp);
        String imageFileName="JPEG_"+timeStamp+"_";
        Log.e("ImageFileName",imageFileName);
        File storageDir=getActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        Log.e("Storage Dir",storageDir.toString());
        File image=File.createTempFile(imageFileName,//Prefix
                ".jpg",//Suffix
                storageDir//Directory
               );
        String imageName=image.getName();
        Log.e("Image Name",imageName);
        mCurrentPhotoPath=image.getAbsolutePath();
        Log.e("mCurrentPhotoPath",mCurrentPhotoPath);
        return image;
    }
    private void imageSaveTOMobileFolder(){
        try {
            Log.e("imageSaveTOMobileFolder",mCurrentPhotoPath);
            ProgressDialog loading=ProgressDialog.show(getContext(),"Loading Image..","Please wait...");
            File storageDir=new File(Environment.getExternalStorageDirectory()+"/ShopProject/media");
            Log.e("Storage Dir",storageDir.toString());
            if(!storageDir.exists()){
                boolean dir=storageDir.mkdirs();
                Log.e("Make Dir",String.valueOf(dir));//path.mkdirs();
            }
            File file=new File(storageDir+"/"+imageName.getName());
            if(!file.exists()){
                Log.e("File not Exist",file.getPath());

                try{
                    FileChannel src = new FileInputStream(mCurrentPhotoPath).getChannel();
                    FileChannel dst = new FileOutputStream(file.getPath()).getChannel();
                    Log.e("Image File Server",file.getPath());
                    dst.transferFrom(src, 0, src.size());
                    src.close();
                    dst.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                loading.dismiss();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        picView.setScaleType(ImageView.ScaleType.FIT_XY);
        switch (requestCode){
            case REQUEST_TAKE_PHOTO:
                if(resultCode== getActivity().RESULT_OK){
                    choosePicMode="fromCamera";

                    picView.setImageBitmap(decodeSampledBitmapFromFile(mCurrentPhotoPath,picView.getMaxHeight(),picView.getMaxWidth()));
                    Log.e("CurrentPhotoPath A Show",mCurrentPhotoPath);
                    imageSaveTOMobileFolder();

                }
                break;
            case SELECT_PICTURE:

                if(resultCode== getActivity().RESULT_OK) {
                    choosePicMode="fromGallery";
                    Uri selectedImage = data.getData();
                    mCurrentPhotoPath=getGalleryImagePath(selectedImage);
                      Log.e("Gallery Image Path",getGalleryImagePath(selectedImage));
                    Log.e("CurrentPhotoPath A Show",mCurrentPhotoPath);
                    picView.setImageBitmap(BitmapFactory.decodeFile(getGalleryImagePath(selectedImage)));

//                    String method="saveData";
//                    BackgroundTask backgroundTask=new BackgroundTask(getContext());
//                    backgroundTask.execute(method,image.getName(),imageToString(decodeSampledBitmapFromFile(getGalleryImagePath(selectedImage),picView.getMaxWidth(),picView.getMaxWidth())));
                    //to know about the selected image width and height

                }



        break;

        }
    }

    public static Bitmap decodeSampledBitmapFromFile(String path,
                                                     int reqHeight, int reqWidth) {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        //Query bitmap without allocating memory
        options.inJustDecodeBounds = true;
        //decode file from path
        BitmapFactory.decodeFile(path, options);
        // Calculate inSampleSize
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        //decode according to configuration or according best match
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        int inSampleSize = 1;
        if (height > reqHeight) {
            inSampleSize = Math.round((float)height / (float)reqHeight);
        }
        int expectedWidth = width / inSampleSize;
        if (expectedWidth > reqWidth) {
            //if(Math.round((float)width / (float)reqWidth) > inSampleSize) // If bigger SampSize..
            inSampleSize = Math.round((float)width / (float)reqWidth);
        }
        //if value is greater than 1,sub sample the original image
        options.inSampleSize = inSampleSize;
        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(path, options);
    }

    public String imageToString(Bitmap bitmap){
        ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);//Compress the image and put it into
        //ByteArrayOutputStream
        byte[] imgByte=byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(imgByte,Base64.DEFAULT);
    }

    public String getGalleryImagePath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = getActivity().getContentResolver().query(uri, projection, null, null, null);
        if (cursor == null) return null;
        int column_index =cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    /* Checks if external storage is available to at least read */
    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }



    class BackgroundTask extends AsyncTask<String,Void,String> {

        String json_String = "";
        JSONObject jsonObject;
        JSONArray jsonArray;
        String temp="";
        String user_name;//, user_pass,user_id;
        // String json_url;
        ProgressDialog loading;
        Context ctx;
        public BackgroundTask(Context context){
            ctx=context;
        }

        @Override
        protected void onPreExecute() {

            // json_url="http://192.168.42.235/Android/SelectData.php";

            //super.onPreExecute();
            loading=ProgressDialog.show(ctx,"Loading Image to the Server..","Please wait...");

        }
        @Override
        protected String doInBackground(String... params) {

            String method=params[0];

            IPConnection ip=new IPConnection();


            if(method.equalsIgnoreCase("saveData")) {

                HashMap<String, String> nameValuePairs = new HashMap<>();
                nameValuePairs.clear();
                nameValuePairs.put("image_name", params[1]);
                nameValuePairs.put("image", params[2]);
                nameValuePairs.put("dsn_name", params[3]);
                nameValuePairs.put("dsn_no", params[4]);
                nameValuePairs.put("dsn_hsn", params[5]);
                nameValuePairs.put("dsn_rate", params[6]);
                nameValuePairs.put("dsn_qty", params[7]);

                String dataseurl=ip.address+ip.uploadimage;
                try {
                    Log.e("DataBase URL",dataseurl);
                    URL url = new URL(dataseurl);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    String data = "";
                    for (String key : nameValuePairs.keySet()) {
                        data += URLEncoder.encode(key, "UTF-8") + "=" + URLEncoder.encode(nameValuePairs.get(key), "UTF-8") + "&";
                        Log.e("Data", data);
                    }
                    bufferedWriter.write(data);
                    Log.e("Data",data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                    StringBuilder builder=new StringBuilder();
                    String line="";
                    while ((line = bufferedReader.readLine()) != null) {
                        builder.append(line+"\n");
                    }
                    Log.i("Message", builder.toString().trim());
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return builder.toString().trim();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return null;
        }

        public String ReadJson(String json_String) {
            String res = null;
            Log.i("Jason String",json_String);
            if(!json_String.equals("")) {
                try {
                    jsonObject = new JSONObject(json_String);
                    res= jsonObject.getString("Android");
                    Log.i("Message",res);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else {
                Log.i("Message","Res ID ERROR");
            }
            return res;
        }

        @Override
        protected void onPostExecute(String result) {
            json_String = result;
            try {
                if(json_String!=null && !json_String.equals(""))
                {
                    loading.dismiss();
                    temp = ReadJson(result);
                    Log.e("On Post Execute=",temp);
                }
            }
            catch (Exception er)
            {}


            if (temp!= null) {
                if (temp.equals("Image not uploaded Successfully")) {

                    Toast.makeText(getContext(), "Data not saved", Toast.LENGTH_LONG).show();
                }
                else if(temp.equals("Image Uploaded Successfully")){
                    Toast.makeText(getContext(), "Data saved Successfully", Toast.LENGTH_LONG).show();
                }

                }

            }

        }

}