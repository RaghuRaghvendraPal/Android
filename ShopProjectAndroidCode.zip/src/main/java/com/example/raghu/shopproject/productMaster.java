package com.example.raghu.shopproject;


import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.io.File;


/**
 * A simple {@link Fragment} subclass.
 */
public class productMaster extends Fragment {
     private String imageName,imagePath;
    private Button savebtn;



    public productMaster() {
        // Required empty public constructor

    }
 public void imageDetail(String imageName,String imagePath){
     this.imageName=imageName;
     this.imagePath=imagePath;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_product_master, container,false);
        savebtn=(Button)view.findViewById(R.id.dsn_save_btn);
        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        return view;
    }

}
